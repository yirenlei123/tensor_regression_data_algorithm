function y = deg2rad(x)

%	y = deg2rad(x)
%
% Fonction qui permet deconvertir des degres (x) en
% radians (y)

y=x*pi/180;