% Sample main script to run the greedy low rank tensor learning algorithm.
% Contact qiyu@usc.edu for questions.

clear
clc
addpath(genpath('./'));
global verbose % Turns on the detailed output.  Set verbose to 0 to only 
verbose = 1;   % see the final results.               

%% Load the series data 
load 'USHCN.mat'
[P,T] = size(data_series{1});

%% Construct the Laplacian matrix
sigma = 0.5; % Laplacian kernel parameter
sim = haverSimple(locations, sigma);
par.sim = sim/(max(sim(:)));       

%% Set parameters 
par.eta = 1e-10; % convergence stopping criteria
par.max_iter = 10; % maximum number of iteration
par.mu = 5; % parameter for Laplacian regularizer
par.train_len = floor(T*0.8);  % training length for forecasting
par.num_lag = 2; % VAR model lag number
% 'forward' calls "forward greedy algorithm"
% 'ortho' calls "orthogonal greedy algorithm"
par.func = 'forward';

%% Cokriging 
% Simulate missing index
idx_missing = (rand(P,1)>0.8);

par.metric = 'K'; % Evaluation function: Kriging
[sol_cokriging, quality_cokriging ] =  greedy_cokriging(data_series,idx_missing, par);
fprintf('cokring rmse %d \n', quality_cokriging(end));      

%% Forecasting
par.metric = 'F'; % Evaluation function: Forecasting
[sols_forecasting, quality_forecasting ] =  greedy_forecasting(data_series, par);
fprintf('forecasting rmse %d \n', quality_forecasting(end));      
