# 导入包
import torch
import numpy as np
import tensorly as tl
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score
from scipy.io import loadmat, savemat
from hopls import matricize, qsquared, HOPLS
from joblib import Parallel, delayed
from generate_data import  generate

# 生成数据, 先模块化调用之前定义的函数.
from generate_data import *
from parallelized_testing import *
from hopls import *
from hopls_numpy import *
from pipeline import *

def mengyu_sun_demo(I1: int, In: tuple, Jm: tuple or list, snr_ls: list
                    , normal_list: list, R, lam_hopls, R_pls):
#  前三个是tensor的维数

    for snr in snr_ls:# 表示不同的噪声
        # snr = 0
        X, Y = generate(I1, In, Jm, R, snr=snr)
        savemat(f"dataset/data_s{I1}_X{len(In) + 1}_Y{len(Jm) + 1}_{snr}dB", {"X": X, "Y": Y})

# 对比 pls 和 hopls 两种方法
    resul = {}
    iter = 0
    for i, snr in enumerate(snr_ls):
        # filename = f"data_X5_Y2_{snr}dB.mat"
        filename = f"dataset/data_s{I1}_X{len(In) + 1}_Y{len(Jm) + 1}_{snr}dB"
        print(filename)
        data = loadmat(filename)
        X = data["X"]
        Y = data["Y"]
        cv = KFold(5)
        PLS_r = []
        PLS_q2 = []
        HOPLS_l = []
        HOPLS_r = []
        HOPLS_q2 = []
        for train_idx, valid_idx in cv.split(X, Y):
            X_train = torch.Tensor(X[train_idx])
            Y_train = torch.Tensor(Y[train_idx])
            X_valid = torch.Tensor(X[valid_idx])
            Y_valid = torch.Tensor(Y[valid_idx])

            results = Parallel(n_jobs=-1)(
                delayed(compute_q2_pls)(X_train, Y_train, X_valid, Y_valid, R)
                for R in range(1, R_pls)
            ) # 这一坨是并行计算

            old_Q2 = -np.inf
            for i in range(R_pls-1):
                # print(results[i].item())
                Q2 = results[i].item()
                # print(Q2)
                if Q2 > old_Q2:
                    best_r = i + 1
                    old_Q2 = Q2
            PLS_r.append(best_r)
            PLS_q2.append(old_Q2) # 把刚刚跑的参数放进来，不要负无穷，并且要其对应的index

            for norm in normal_list: # 考虑三种正则化方式
                X_train = norm(X_train)
                X_valid = norm(X_valid)
                Y_train = norm(Y_train)
                Y_valid = norm(Y_valid)
                results = Parallel(n_jobs=-1)(
                    delayed(compute_q2_hopls)(X_train, Y_train, X_valid, Y_valid, lam)
                    for lam in range(1, lam_hopls) # lam表示X分解的tucker秩个数
                )
                old_Q2 = -np.inf
                for i in range(lam_hopls-1):
                    r, Q2 = results[i]
                    # Q2 = Q2.item()
                    # print(max(Q2))
                    if max(Q2).item() > old_Q2:
                        best_lam = i + 1
                        best_r = r
                        old_Q2 = max(Q2).item()

                # print("best param is R=" + str(best_params["R"]))
                # print("Q2: " + str(Q2))
                HOPLS_l.append(best_lam) # 最佳的秩个数
                HOPLS_r.append(best_r) # 返回r
                HOPLS_q2.append(old_Q2)# 每一折对应的最佳得分
        # hyper.append(PLS_r)
        # mat.append(PLS_q2)

        # 用来存储结果
        re1 = 'PLS_r'+str(iter)
        re2 = 'PLS_q2的均值'+str(iter)
        re3 = 'HOPLS_r'+str(iter)
        re4 = 'HOPLS_l'+str(iter)
        # re5 = 'HOPLS_q2'+str(i)
        re6 = '三种标准化的结果（k折均值）' + str(iter)

        resul[re1] =  PLS_r
        resul[re2] = np.mean(PLS_q2)
        resul[re3] = HOPLS_r
        resul[re4] = HOPLS_l
        # resul[re5] = HOPLS_q2
        resul[re6] = [np.mean(HOPLS_q2[:5]), np.mean(HOPLS_q2[5:10]), np.mean(HOPLS_q2[10:15])]

        iter += 1

        # print(f'第{i+1}轮')
        # print("PLS")
        # print(PLS_r, np.mean(PLS_q2)) # 表示五折CV下，每一个最好的r和平均的得分。
        # print("HOPLS")
        # print(HOPLS_r)
        # print(HOPLS_l)
        # print(HOPLS_q2)
        # print(np.mean(HOPLS_q2[:5]), np.mean(HOPLS_q2[5:10]), np.mean(HOPLS_q2[10:15]))
    # savemat(
    #     "PLS_res.mat", {"best_ncomp_test": np.array(hyper), "q2_test": np.asarray(mat)}
    # )
    return resul


if __name__ == '__main__':
    I1 = 20
    In = (10, 10)
    Jm = [10] # 如果是维数>=2, tuple like (10,10) 是需要的。
    lam_hopls = 10  #  R_pls， lam_hopls 这两个参数可能需要你自己调一下我不知道啥意思，
    R_pls = 10
    snr_ls = [10, 5, 0, -5] # 表示四种snr的数据
    normal_list = [normalize1, normalize2, normalize3]
    mat = [] # mat 和 hyper似乎作者没用
    hyper = []
    R = 5  # 表示生成X 和 Y时候的rank
    result_iter = mengyu_sun_demo(I1, In, Jm, snr_ls, normal_list, R, lam_hopls, R_pls)
    print(result_iter)