import numpy as np
import tensorly as tl
from scipy.io import savemat
from itertools import product
from tensorly.decomposition import tucker
from sklearn.model_selection import KFold
# from tensorly.tenalg import mode_dot, multi_mode_dot, kronecker
import torch

tl.set_backend("pytorch")
torch.set_default_tensor_type(torch.DoubleTensor)
torch.set_default_dtype(torch.float64)

# 生成数据
from generate_data import generate_complex
# 找最佳 lam 和 R
from pipeline import do_testing, compute_q2_hopls_coef
# 找lam、R 下的系数tensor
from hopls import HOPLS

import scipy.io as scio
import time
def rmse(ypred,yture):
    return np.sqrt(np.linalg.norm(ypred-yture)**2/yture.numel())
bestrmse=1000
tm=0
Rmax=range(1,30)
lam=range(1,4)
trainx=scio.loadmat('D:/工作管理/实验数据/1/vid_trainx.mat')
trainx=tl.tensor(trainx['trainx']).double()
trainy=scio.loadmat('D:/工作管理/实验数据/1/vid_trainy.mat')
trainy=tl.tensor(trainy['trainy']).double()
testx=scio.loadmat('D:/工作管理/实验数据/1/vid_testx.mat')
testx=tl.tensor(testx['testx']).double()
testy=scio.loadmat('D:/工作管理/实验数据/1/vid_testy.mat')
testy=tl.tensor(testy['testy']).double()
valx=scio.loadmat('D:/工作管理/实验数据/1/vid_valx.mat')
valx=tl.tensor(valx['valx']).double()
valy=scio.loadmat('D:/工作管理/实验数据/1/vid_valy.mat')
valy=tl.tensor(valy['valy']).double()
# samplelist=[np.array(range(140,340,20)),np.array(range(140,340,20))]
bestrmse_list=[]
time_list=[]
cor_list=[]
q2_list=[]
bestR=0
bestlam=0
for i in range(1):#重复十次实验
    for i in range(len(Rmax)):
        for j in range(len(lam)):

            start=time.time()
            y_pred, coef = compute_q2_hopls_coef(trainx, trainy, testx, testy,la=lam[j], R_max=Rmax[i])
            end=time.time()
            rmse0=rmse(y_pred,testy)
            if rmse0<bestrmse:
                bestrmse=rmse0
                tm=end-start
                cor=np.corrcoef(y_pred.flatten(),testy.flatten())
                Q2=1-np.linalg.norm(y_pred-testy)**2/np.linalg.norm(testy)**2
                NRMSE = bestrmse / torch.mean(testy.flatten())
                MAE = sum(np.abs(y_pred.flatten() - testy.flatten())) / len(testy.flatten())
                NMAE = MAE / torch.mean(testy.flatten())
                bestR=Rmax[i]
                bestlam=lam[j]
    bestrmse_list.append(bestrmse)
    time_list.append(tm)
    cor_list.append(cor[0][1])
    q2_list.append(Q2)

print('bestrmse:',bestrmse_list)
print('time:',time_list)
print('cor:',cor_list)
print('Q2:',q2_list)
print('NRMSE:',NRMSE)
print('MAE:',MAE)
print('NMAE:',NMAE)
print('Rmax:',bestR)
print('bestlam:',bestlam)

# np.save(file="horll_twdata_tm10.npy", arr=tm)
# np.save(file="horll_twdata_rmse10.npy", arr=predrmse)
